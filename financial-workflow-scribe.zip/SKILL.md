---
name: financial-workflow-scribe
description: Automates financial workflows across various payment and banking applications, including Chime, Cash App, MoneyLion, SoFi, and Cleo. Use this skill to toggle payment statuses, sync financial data, and automate notifications across these platforms, primarily through browser automation and notification triggers.
---

# Financial Workflow Scribe

## Overview

This skill enables Manus to manage and automate financial tasks across several popular payment and banking applications. It focuses on synchronizing payment statuses, tracking financial activities, and facilitating automated updates based on predefined triggers.

## Core Capabilities

### 1. Toggle Payment Status

This capability allows Manus to update the payment status for a specified application. It utilizes a local script to maintain a centralized record of payment statuses, which can then be used to trigger further actions or notifications.

**Usage:**

To toggle the payment status for an application, use the `toggle_payment.py` script located in the `scripts/` directory. This script updates a local JSON file (`financial_status.json`) that acts as a central log for payment statuses.

```bash
python3 /home/ubuntu/skills/financial-workflow-scribe/scripts/toggle_payment.py <app_name> <new_status>
```

- `<app_name>`: The name of the financial application (e.g., `Chime`, `Cash App`, `MoneyLion`, `SoFi`, `Cleo`).
- `<new_status>`: The desired payment status (e.g., `paid`, `pending`, `received`, `failed`).

**Example:**

```bash
python3 /home/ubuntu/skills/financial-workflow-scribe/scripts/toggle_payment.py Cash App paid
```

### 2. Automated Posting and Syncing

This skill facilitates the automated posting and syncing of financial information across the supported applications. Due to the nature of these mobile-first applications, direct API integrations are often limited. Therefore, the automation strategy involves:

-   **Browser Automation**: For interacting with web interfaces of the financial applications to check statuses or initiate actions.
-   **Notification Triggers**: Utilizing the `gmail` MCP server to monitor for email notifications related to transactions or status changes from these apps.
-   **Centralized Data Log**: Maintaining a `financial_status.json` file (managed by `toggle_payment.py`) to keep track of the latest payment statuses across all integrated platforms.

When a status change is detected (e.g., a new deposit in Chime via email notification), Manus will update the central log and can then be instructed to perform subsequent actions, such as updating a budget in Cleo or sending a summary to a designated communication channel.

## Supported Applications

This skill is designed to work with the following financial applications. Detailed integration methods and automation strategies for each can be found in the `app_integrations.md` reference file.

-   **Chime**
-   **Cash App**
-   **MoneyLion**
-   **SoFi**
-   **Cleo**

## Resources

This skill includes the following bundled resources:

### scripts/

-   `toggle_payment.py`: A Python script to update the payment status in a centralized `financial_status.json` file.

### references/

-   `app_integrations.md`: Provides detailed information on the integration methods and automation strategies for each supported financial application.

### templates/

(No specific templates are currently included, but this directory can be used for any boilerplate files needed for future expansions, such as report formats or notification templates.)
