import json
import sys
import os

STATUS_FILE = "/home/ubuntu/financial_status.json"

def load_status():
    if os.path.exists(STATUS_FILE):
        with open(STATUS_FILE, 'r') as f:
            return json.load(f)
    return {"payments": {}}

def save_status(status):
    with open(STATUS_FILE, 'w') as f:
        json.dump(status, f, indent=4)

def toggle_payment(app_name, status):
    data = load_status()
    data["payments"][app_name] = status
    save_status(data)
    print(f"Successfully toggled {app_name} payment status to: {status}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 toggle_payment.py <app_name> <status>")
        sys.exit(1)
    
    app = sys.argv[1]
    new_status = sys.argv[2]
    toggle_payment(app, new_status)
