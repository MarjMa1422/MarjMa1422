# Financial App Integrations

This reference guide outlines the integration methods for the supported financial apps. Since most of these apps are mobile-first and do not provide public consumer APIs for personal automation, the "Scribe" workflow relies on browser automation, manual status tracking, and notification-based triggers.

## Supported Apps

### 1. Chime
- **Primary Use**: Checking and savings, cash advances.
- **Integration**: Browser-based login for status checks.
- **Automation**: Monitor for deposit notifications via Gmail.

### 2. Cash App
- **Primary Use**: Peer-to-peer payments, Cash App Pay.
- **Integration**: Cash App Pay SDK (for business) or browser-based activity monitoring.
- **Automation**: Syncing transaction history to a central log.

### 3. MoneyLion
- **Primary Use**: Cash advances (Instacash), mobile banking.
- **Integration**: Browser-based account management.
- **Automation**: Toggling payment statuses for advances.

### 4. SoFi
- **Primary Use**: Banking, investments, loans.
- **Integration**: Browser-based portal.
- **Automation**: Consolidating financial data.

### 5. Cleo
- **Primary Use**: AI money coaching, budgeting, cash advances.
- **Integration**: Web interface (meetcleo.com).
- **Automation**: Interacting with the Cleo AI coach for budget updates.

## Automation Strategy

1. **Centralized Log**: Maintain a `financial_status.json` or Google Sheet to track "toggled" statuses across all platforms.
2. **Notification Triggers**: Use the `gmail` MCP server to detect status changes from these apps.
3. **Cross-Platform Sync**: When a status changes in one app (e.g., a deposit in Chime), automatically update the status in the central log and notify other relevant apps (e.g., Cleo for budgeting).
